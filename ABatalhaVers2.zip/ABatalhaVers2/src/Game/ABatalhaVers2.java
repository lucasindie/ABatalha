package Game;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JFrame;

import javax.swing.Timer;
public class ABatalhaVers2 extends JPanel implements ActionListener, KeyListener {
	 
	  
	Rectangle platform = new Rectangle(170, 34, 40, 50);
	
	private final int B_WIDTH = 350;
	private final int B_HEIGHT = 350;
	private final int INICIAL_X = 170;
	private final int INICIAL_Y= 34;
	private final int INICIAL_LARGURA = 40;
	private final int INICIAL_ALTURA = 50;
	private final int DELAY = 50; //controla  a velocidade da anima��o
	private Timer timer;
	private int x, y, largura, altura;
        private int player_x, player_y;
	

	/*Nessa vers�o: "A Batalha vers�o 2" /_Lucas, o loop utilizado � o: Swing timer, diferente da Vers�o 1 nesse podemos controlar a velocidade atrav�s do DELAY
	 * da anima��o.
	 */
	public ABatalhaVers2(){
		//setSize(new Dimension(500, 400));
		//setPreferredSize(new Dimension(500, 400));
		setBounds(0, 0, 500, 400);
		setBackground(Color.gray);
		setFocusable(true);
		
		
		x = INICIAL_X;
		y = INICIAL_Y;
		largura = INICIAL_LARGURA;
		altura = INICIAL_ALTURA;
	
          
		//Swing Timer: Respons�vel pela anima��o.		
		timer = new Timer(DELAY, this);// aqui podemos controlar a velocidade da anima��o, atrav�s da vari�vel DELAY
		timer.start(); //O m�todo actionPerformed()  � automaticamente e repetidamente invocado pelo uso do timer.
		 
                player_x = 150;
                player_y = 200;
	 
		 addKeyListener(this);
		 
	}

 
 public static void main(String[] args) {
	 
	ABatalhaVers2 gamemain = new ABatalhaVers2();
	 
	 
	 JFrame f = new JFrame("A Batalha versao 2 by: lucasindiesh1p.wordpress.com/");
		// f.setTitle("Game");
	 f.add(gamemain);
	 f.setSize(700, 500);
	 f.setLayout(null);
	 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 //f.pack(); //ajusta os componentes na dimens�o do jpanel  
	 f.setVisible(true);
        
 }
 
 
 public void desenharEfeito(Graphics g) {
	 g.setColor(Color.orange);
	 g.fillRect(x, y, largura, altura);
	 Toolkit.getDefaultToolkit().sync();//sem essa linha a anima��o n�o vai ficar boa no Linux.
 }
 
 @Override
 public void paintComponent(Graphics g) {
     super.paintComponent(g);

     g.setColor(Color.BLACK);
	 g.fillRect(0, 0, getWidth(), getHeight());
	 
	 g.setColor(Color.white);
	 g.setFont(new Font("Century Gothic", Font.BOLD, 10));
	 g.drawString("A Batalha - metodo de loop: Swing timer", 0, 10);
	 
         g.setColor(Color.white);
	 g.setFont(new Font("Century Gothic", Font.BOLD, 10));
	 g.drawString("Aperte 'A' para ir para mover para esquerda ou 'D' para mover para direita", 0, 300);
	 
	
	g.setColor(Color.white);
	g.fillRect(platform.x, platform.y, platform.width, platform.height);
	
	g.setColor(Color.gray);
	g.fillOval(player_x, player_y, platform.width, platform.height);
	
     desenharEfeito(g);
 }
 
 
public void actionPerformed(ActionEvent e) {
//efeito animado
x -= 1;
largura += 2;
y -= 1;
altura += 2;

if(y <INICIAL_Y - 10) {
	y = INICIAL_Y;
	altura = INICIAL_ALTURA;
	
	if(x < INICIAL_X - 20)
		x = INICIAL_X;
		largura = INICIAL_LARGURA;
   
}
	repaint(); //Chama m�todo  paintComponent
}
 
 
    public void keyTyped(KeyEvent e) {
         
    }


    public void keyPressed(KeyEvent e) {
     int c = e.getKeyCode();

	 if(c == KeyEvent.VK_A) {
		player_x -= 4;
	
	 }
	 if(c == KeyEvent.VK_D) {
		player_x += 4;
		
	 }
	 }

    
    public void keyReleased(KeyEvent e) {
         
    }
 
}
